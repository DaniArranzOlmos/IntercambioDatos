package com.example.intercambiodedatos;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class Registro extends AppCompatActivity {

    private Button registro;
    private EditText nombre;
    private EditText contrasenha;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_registro);

        registro = findViewById(R.id.registro);
        nombre = findViewById(R.id.nombre);
        contrasenha = findViewById(R.id.contrasenha);
        nombre.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    nombre.setText("");
                }
            }
        });

        registro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                registrarse(view);
            }
        });

    }
    public void registrarse(View v)
    {
        String n = nombre.getText().toString();
        String c = contrasenha.getText().toString();

        Intent registro = new Intent(this, Login.class);

        registro.putExtra("nombre", n);
        registro.putExtra("contrasenha", c);

        startActivity(registro);

    }
}