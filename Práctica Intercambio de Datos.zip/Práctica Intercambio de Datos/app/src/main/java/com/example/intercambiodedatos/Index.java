package com.example.intercambiodedatos;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class Index extends AppCompatActivity {
    private TextView nombreIndex;
    private TextView nombreIndex1;
    private TextView contrasenhaIndex;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_index);

        nombreIndex = findViewById(R.id.nombreIndex);
        nombreIndex1 = findViewById(R.id.nombreIndex1);
        contrasenhaIndex = findViewById(R.id.contrasenhaIndex);

        Intent login = getIntent();
        String nombreRecibido = login.getStringExtra("nombre");
        String contrasenhaRecibida = login.getStringExtra("contrasenha");

        nombreIndex.setText(nombreRecibido);
        nombreIndex1.setText(nombreRecibido);
        contrasenhaIndex.setText(contrasenhaRecibida);
    }
}