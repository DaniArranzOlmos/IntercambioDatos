package com.example.intercambiodedatos;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Login extends AppCompatActivity {

    private Button login;
    private EditText nombre;
    private EditText contrasenha;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);

        login = findViewById(R.id.login);
        nombre = findViewById(R.id.nombreLogin);
        contrasenha = findViewById(R.id.contrasenhaLogin);

        Intent registro = getIntent();
        String nombreRecibido = getIntent().getStringExtra("nombre");
        String contrasenhaRecibida = getIntent().getStringExtra("contrasenha");

        nombre.setText(nombreRecibido);
        contrasenha.setText(contrasenhaRecibida);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                logearse(view);
            }
        });

    }
    public void logearse(View v)
    {
        String n = nombre.getText().toString();
        String c = contrasenha.getText().toString();

        Intent login = new Intent(this, Index.class);

        login.putExtra("nombre", n);
        login.putExtra("contrasenha", c);

        startActivity(login);

    }
}